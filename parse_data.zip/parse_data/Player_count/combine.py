
from os import write


w_f=open("./2021-11-total",'w')


for i in range(16,31,1):
    token=str(i)
    f=open("./2021-11-"+token+"-2",'r')
    
    while(True):
        line=f.readline()
        
        if(line==''):
            break
        else:
            w_f.write(line)    
    
    f.close()
    

w_f.close()




    