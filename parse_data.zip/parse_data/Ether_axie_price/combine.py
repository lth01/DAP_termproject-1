
from os import write


write_ether_f=open("./2021-11-ether-total",'w')
write_axie_f=open("./2021-11-axie-total",'w')

for i in range(16,31,1):
    token=str(i)
    f=open("./2021-11-"+token+"-ether",'r')
    f2=open("./2021-11-"+token+"-axie",'r')
    while(True):
        line=f.readline()
        
        if(line==''):
            break
        else:
            write_ether_f.write(line)    
    while(True):
        line2=f2.readline()
        if(line2==''):
            break
        else:
            write_axie_f.write(line2)
    f.close()
    f2.close()

write_axie_f.close()
write_ether_f.close()

    